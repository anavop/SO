#include<stdio.h>
#include "queue.h"
int queue_size (queue_t *queue) {
    int cont = 0;
   
    if (queue == NULL)// se a fila for vazia 
        return cont;

    
    // se a fila nao for vazia
    cont ++;
    queue_t *aux = queue;
     while (aux->next != queue){
        aux = aux->next;
        cont++;
     }
    return cont;
    
}
//------------------------------------------------------------------------------
// Percorre a fila e imprime na tela seu conteúdo. A impressão de cada
// elemento é feita por uma função externa, definida pelo programa que
// usa a biblioteca. Essa função deve ter o seguinte protótipo:
//
// void print_elem (void *ptr) ; // ptr aponta para o elemento a imprimir

void queue_print (char *name, queue_t *queue, void print_elem (void*) ) {   

        printf("%s \n[",name);
        queue_t *aux = queue;
        if (queue != NULL){
            if (aux->next == aux){
                print_elem(aux);
            }
            else{
                while(aux->next != queue){
                    print_elem(aux);
                    printf(" ");
                    aux = aux->next;
                }
                print_elem(aux);
            }
        }
        printf("] \n");

    }
   
    
     
//------------------------------------------------------------------------------
// Insere um elemento no final da fila.
// Condicoes a verificar, gerando msgs de erro:
// - a fila deve existir
// - o elemento deve existir
// - o elemento nao deve estar em outra fila
// Retorno: 0 se sucesso, <0 se ocorreu algum erro

int queue_append (queue_t **queue, queue_t *elem) {
   
    //printf("prev %p  next %p \n",elem->prev,elem->next);
    if (elem->next&&elem->prev) // se o elemento existe em outra fila
        return -1;
    
    if(elem == NULL) // se o elemento nao existir
        return -1;
     

    if (*queue == NULL){ // se a fila for vazia 
    
    (*queue) = elem;
    elem->next = elem;
	elem->prev = elem;
    return 0;
    //printf("entrou na fila vazia \n");
    }
    // se a fila for diferente de vazia 
        //printf(" tam da fila %d\n",(queue_size(*queue)));
       // printf("entrou na fila nao vazia \n");
        queue_t * aux = *queue;
    
       if ((queue_size(*queue)) ==1){ // se o tamanho da fila for igual a 1
        // printf("entrou na fila de tamanho 1 \n");
            if (aux == elem){ //elemento ja extistente 
                printf("elem ja existe");
                return -1;
            }
            elem->prev = (*queue);
            elem->next = (*queue);
            (*queue)->next = elem;
            (*queue)->prev = elem;
            return 0;
            //printf("prev %p  next %p \n",elem->prev,elem->next);

       }
       // se a fila for maior do que um elemento
        //printf("FILA MAIOR QUE 1");
        while (aux->next != *queue){   
            aux = aux->next;
            if (aux == elem) //elemento ja extistente 
                return -1;
            
           //print_elem(aux);
           // printf(" aux %p \n",aux);
        }
        (*queue)->prev = elem;
        aux->next= elem;
        elem->prev = aux;
        elem->next = (*queue);
        //printf("prev %p  next %p \n",elem->prev,elem->next);
        return 0;
        } 

//------------------------------------------------------------------------------
// Remove o elemento indicado da fila, sem o destruir.
// Condicoes a verificar, gerando msgs de erro:
// - a fila deve existir
// - a fila nao deve estar vazia
// - o elemento deve existir
// - o elemento deve pertencer a fila indicada
// Retorno: 0 se sucesso, <0 se ocorreu algum erro

int queue_remove (queue_t **queue, queue_t *elem) {
    
    
    if(queue == NULL)// Verifica se a struct existe
        return 1;    
    
    if (*queue == NULL) //fila vazia entao nao da para remover
        return 1;

    if(elem == NULL)// Verifica se o elemento existe
        return 1;
    
    queue_t * aux = *queue;
    if ((queue_size(*queue) == 1)&& ((*queue) !=elem)) // se a fila for de tamanho 1 e os elementos forem diferentes
         return 1;   

    if (queue_size(*queue) == 1){

            aux->next = NULL;
            aux->prev = NULL;
            (*queue)= NULL;
            return 0;
            }
        
        while ((aux->next != (*queue)) && (aux !=elem)){ // percorre a fila ate que tenha chegado no *queue incial ou achar o elemento
            aux = aux->next;
            
        }   
            if (aux == elem){ // se o elemento esta na fila 
                
               // printf("ENTROU  aux = elem \n");
                //print_elem(aux);
                aux->next->prev = aux->prev;
                aux->prev->next = aux->next;
                if (elem == (*queue)){ // se for o primeiro elemento da fila
                    (*queue) = aux->next;
                
                }
                aux->next = NULL;
                aux->prev = NULL;
                
                return 0;
        }      
        printf("elem nao encontrado "); 
        return -1;
        }

    


