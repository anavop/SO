#include <stdio.h>
#include <stdlib.h>
#include <ucontext.h>
#include "ppos.h"
#include "queue.h"
#include <string.h>
#define STACKSIZE 64*1024
int usersTask =0;
int lastID =0;
task_t * atual, taskMain;
task_t * Filadispatcher,disp; // header da fila dispatcher e a task onde armazena o dispatcher
task_t * proximo; // ponteriro que ira percorrer a fila dispatcher
short AGUARDANDO = 0;
short TERMINADA = 1;
short SUSPENSA,OCUPADO;
void Dispatcher();
//Esta função inicializa as estruturas internas do SO
void ppos_init (){

char* stack = malloc (STACKSIZE) ;
setvbuf (stdout, 0, _IONBF, 0);

if (stack){ // verifica se a stack que armazenara os valores da tarefa main foi armazenado com sucesso
    taskMain.id = 0;
    taskMain.prev = NULL;
    taskMain.next = NULL;
    taskMain.status = AGUARDANDO;
    taskMain.context.uc_stack.ss_sp = stack ;
    taskMain.context.uc_stack.ss_size = STACKSIZE ;
    taskMain.context.uc_stack.ss_flags = 0 ;
    taskMain.context.uc_link = 0 ;
    taskMain.Sprio= 20;
    taskMain.Dprio = 20;
    atual = &taskMain ; // salva o contexto atual na variável MAIs
    
   task_create(&disp,(void*)Dispatcher,NULL);

    
}
else{
    perror ("Erro na criação da pilha: ") ;
    exit (1) ;
}
} 

void task_setprio (task_t *task, int prio){ //atribui uma prio a task tanto a estatica quanto a dinamica inicialmente com mesmo valor 

    task->Dprio = prio;
    task->Sprio = prio;

}

int task_getprio (task_t *task){ // 
    if(task) // se a task exitir retorna a atual prio se nao retorna a task atual que tem prio
        return task->Sprio;
    else
        return atual->Sprio;
}

task_t * scheduler(){ //  funcao que encaminha para o proximo 
   
	task_t * head = proximo ; 
    task_t * maiorPrio = &(*Filadispatcher);  // define a funcao de maior prioridade
    
   
    if (head->next != NULL){ // se a fila nao for vazia
    
        while (head->next != proximo){// percorre toda a fila em busca da maior prioridade
        if (head->Dprio < maiorPrio->Dprio){

            maiorPrio = head;
        }
        else // se não for maior prio  altera prio dinamica da task
            head->Dprio--;
        head = head->next;
        }

    maiorPrio->Dprio = maiorPrio->Sprio; // retorna prio inicial pra task que acabou de ser executada
    
    }
    return maiorPrio->next;
    
}


void Dispatcher(){
    int cont = 0;
    proximo = &(*Filadispatcher); // salva o valor inicial do proximo que ira percorrer a fila do dispatcher
    while (usersTask>0){ // enquanto a task nao for igual a 1

       proximo = scheduler(); 

    // pega o proximo elementoaDispatcher
    
        //salva a posicao do elemento da fila que sera usado na funcao schuduler
        if (proximo->prev != NULL){
           
            task_switch(proximo->prev); // troca pra task anterior

        if (proximo->prev->status == TERMINADA){
            usersTask--;
            queue_remove((queue_t **)&Filadispatcher,(queue_t*) proximo->prev);
    
        }
        cont++;
    }
   
     }
    exit(0); // voltou pra main 
}

void task_yield (){ // entra no dispatcher

    task_switch(&(disp));
}
/*task: estrutura que referencia a tarefa criada
start_routine: função que será executada pela tarefa
arg: parâmetro a passar para a tarefa que está sendo criada
retorno: o ID (>0) da tarefa criada ou um valor negativo, se houver erro
*/
int task_create (task_t *task, void (*start_routine)(void *),  void *arg) { //cria task  
    char *stack;
    getcontext(&task->context);
    stack = malloc (STACKSIZE) ;
    if (stack) // verifica se a stack que armazenara os valores da tarefa foi armazenado com sucesso
    {
    
        task->context.uc_stack.ss_sp = stack ;
        task->context.uc_stack.ss_size = STACKSIZE ;
        task->context.uc_stack.ss_flags = 0 ;
        task->context.uc_link = 0 ;
        task->id = usersTask++;
    
        if (usersTask>1){
            queue_append((queue_t **)&Filadispatcher, (queue_t *) task);
            lastID = task->id;
            task->status = AGUARDANDO;
        
            }
        else 
            task->Dprio =20;
    }
    else {
    perror ("Erro na criação da pilha: ") ;
    exit (1) ;
    }
    
    makecontext(&(task->context),(void*)(*start_routine), 1,arg); //salva o contexto da task criada e começa uma rotina
    
    return 0;
}

int task_switch (task_t *task){ // troca de tarefa


    task_t * old;
    old =  atual;
    atual = task;
   
    swapcontext(&(old->context), &(atual->context)); // TROCA O CONTEXTO DA TAREFA SAI DE old e vai para a nova atual 
    return 0;
}


void task_exit (int exit_code){
    
    // enquanto as fila nao for diferente do header retorna pro dispatcher

        
       if (atual->id != lastID ) // se for diferente da ultima tarefa na fila retorna ao task yield , se nao sai do dispater
        atual->status = TERMINADA;{ //altera o status da tarefa enquanto a ultima tarefa executada quando e finalizada
       task_yield();
       }
    
    task_switch(&taskMain);
       
   
}

int task_id (){ // retorna o id da tarefa em execução
    return atual->id;
}